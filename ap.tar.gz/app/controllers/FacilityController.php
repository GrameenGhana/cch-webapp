<?php

class FacilityController extends BaseController {

	private $districts;
	private $rules;

	public function __construct()
	{
  	   $this->beforeFilter('auth');

	   $this->districts = array(
		'Greater Accra'=> array('Ada East'=>'Ada East','Ada West'=>'Ada West', 'Ningo Prampram'=>'Ningo Prampram','Accra Metro'=>'Accra Metro'),
		'Volta'        => array('South Dayi'=>'South Dayi', 'South Tongu'=>'South Tongu','Ho Municipal'=>'Ho Municipal'));

	   $this->rules = array('name' => 'required|min:3', 'district'=>'required');

	}

    public function showPeople($fid)
    {
         $fac = Facility::find($fid);
         return View::make('facilities.people',array('facility'=>$fac));
    }

 	public function showCalendar($id)
	{
	   	$facility = Facility::find($id);
           	$events = array();

       		foreach($facility->users as $u) {
     	           	$logs = $u->tracklogs()->where('module','=','Calendar')->get();
                	foreach($logs as $log) {
                        	$e = $this->createEventForJS($log->data, $log->start_time, $log->end_time);
                        	if ($e != null) {
                            	$s = serialize($e);
                            	$events[$s] = $e;
			   
                        	}
                	}
//         print '<pre>'; print_r($events); print '</pre>';
	 return View::make('facilities.calendar',array('facility'=>$facility,'events'=>$events));
       		}
	 //  return View::make('facilities.calendar',array('facility'=>$facility,'events'=>$events));
	 }
	
    public function showDistrictCalendar($id, $district)
    {
            $user = User::find($id);
            $events = array();
            $legend = array();

            foreach($user->facilities as $facility)
            {
                if ($facility->district == $district) {
                    $bg = '#'.$this->random_color();
                    $legend[$facility->name] = $bg;

                    foreach($facility->users as $u) 
                    {
                        $logs = $u->tracklogs()->where('module','=','Calendar')->get();
                        foreach($logs as $log) {
                            $e = $this->createEventForJS($log->data, $log->start_time, $log->end_time, $bg, $bg);
                            if ($e != null) {
                                $s = serialize($e);
                                $events[$s] = $e;
                            }
                        }
                        break;
                    }
                }
            }
            return View::make('facilities.districtcalendar',array('district'=>$district,'events'=>$events,'legend'=>$legend));
     }

	public function index()
	{
	   $facs = Facility::all();
	   return View::make('facilities.index',array('facilities'=>$facs));
	}

	public function show($id)
	{
	   $facility = Facility::find($id);
	   return View::make('facilities.show',array('facility'=>$facility));
	}

	public function create()
	{
	   return View::make('facilities.create',array('districts'=>$this->districts));
	}

	public function store()
	{
	    $validator = Validator::make(Input::all(), $this->rules);	

	    $validator->sometimes('motechid', 'numeric|digits:5', function($input) {
		return $input->motechid <> '';
	    });
	    

	    if ($validator->fails()) {
		return Redirect::to('/facilities/create')
			->with('flash_error','true')
			->withErrors($validator);
	    } else {
		$facility = new Facility;
		$facility->name = Input::get('name');
		$facility->district = Input::get('district');
		$facility->sub_district = Input::get('sub_district');
		$facility->motech_facility_id = Input::get('motechid');
		$facility->region = $this->getRegionFromDistrict(Input::get('district'));
		$facility->created_at = date('Y-m-d h:m:s'); 
		$facility->modified_by = Auth::user()->id; 

		// using default values - consider changing
		$facility->country = 'Ghana';

		$facility->save();
		//print '<pre>'; print_r($facility); print '</pre>'; exit;

		Session::flash('message',"{$facility->name} created successfully");
		return Redirect::to('/facilities');
	    }
	}

	public function edit($id)
	{
	   $facility = Facility::find($id);
	   return View::make('facilities.edit',array('facility'=>$facility,'districts'=>$this->districts));
	}

	public function update($id)
	{
	    $validator = Validator::make(Input::all(), $this->rules);	

	    $validator->sometimes('motechid', 'numeric|digits:5', function($input) {
		return $input->motechid <> '';
	    });

	    if ($validator->fails()) {
		return Redirect::to('facilities/'.$id.'/edit')
			->with('flash_error','true')
			->withInput()
			->withErrors($validator);
	    } else {
		$facility = Facility::find($id);
		$facility->name = Input::get('name');
		$facility->district = Input::get('district');
		$facility->sub_district = Input::get('sub_district');
		$facility->motech_facility_id = Input::get('motechid');
		$facility->region = $this->getRegionFromDistrict(Input::get('district'));
		$facility->modified_by = Auth::user()->id; 
		$facility->save();

		Session::flash('message',"{$facility->name} updated successfully");
		return Redirect::to('facilities');
	    }
	}

	public function destroy()
	{
	   $facs = Facility::all();
	   return View::make('facilities.index',array('facilities'=>$facs));
	}

	private function getRegionFromDistrict($district)
	{
		foreach($this->districts as $region => $districts)
		{
			foreach($districts as $d)
			{
				if ($d == $district) return $region;
			}
		}
		return 'unknown';
	}
}
