<?php

class UserController extends BaseController {
        
	public function __construct()
    {

      
  $this->beforeFilter('auth',array('except'=>'store'));

        $facs = Facility::all(); 
	    $this->facilities = array();
	    $this->pfacilities = array('Other'=>'Unknown');

	    foreach($facs as $k => $v){
		   if(in_array($v->district,array_keys($this->facilities))) {
			  array_push($this->facilities[$v->district], $v);
			  $this->pfacilities[$v->district][$v->id] = $v->name;
		   } else {
			  $this->facilities[$v->district] = array($v);
			  $this->pfacilities[$v->district] = array($v->id=>$v->name);
		  }
	    }


        $this->groups = array('GHS'=>'GHS','CCH'=>'CCH');
	    $this->roles = array('GHS'=>array('Nurse'=>'Nurse',
                                          'Supervisor'=>'Supervisor',
                                          'Sub-District Supervisor'=>'Sub-District Supervisor',
                                          'District Supervisor'=>'District Supervisor',
                                          'Regional Supervisor'=>'Regional Supervisor',
                                          'National Supervisor'=>'National Supervisor'),
			                   'CCH'=>array('Researcher'=>'Researcher',
                                            'GF'=>'GF','Concern'=>'Concern', 'Admin'=>'admin'));

        $this->rules = array('username' => 'required|min:3|unique:cch_users', 
			                 'password' => 'required|min:6',
			                 'confirmpassword' => 'required|same:password',
			                 'first_name' => 'required|min:2',
			                 'last_name' => 'required|min:2',
			                 'group' => 'required|min:2',
			                 'role' => 'required|min:2'
	       );
    }

    public function showCalendar($id)
    {
       $events = array();

       $user = User::find($id);
       $logs = $user->tracklogs()->where('module','=','Calendar')->get();

       foreach($logs as $log) {
               $e = $this->createEventForJS($log->data, $log->start_time, $log->end_time);
               if ($e != null) {
                   $s = serialize($e);
                   $events[$s] = $e;
               }
       }
       return View::make('users.calendar',array('user'=>$user,'events'=>$events));
    }

    public function showCourses($id)
    {
       $user = User::find($id);
       $courses = $user->courses();
       return View::make('users.courses',array('user'=>$user, 'courses'=>$courses));
    }

	public function index()
	{
	   $users = User::all();
	   return View::make('users.index',array('users'=>$users));
	}


	public function create()
	{
        $d = Device::where('status','=','unallocated')->get();
        $devices = array('0'=>'Unknown'); 
        foreach($d as $k => $v) { $devices[$v->id] = $v->type.' - '.$v->tag; } 

	   return View::make('users.create', array('groups' => $this->groups,
					     'roles'  => $this->roles,
 						 'devices' => $devices,
 						 'pfacilities' => $this->pfacilities,
 						 'facilities' => $this->facilities));
	}

    public function edit($id)
    {
       $user = User::with('facilities')->find($id);
	   $user->listAttributes($user,'facilities');
       $user->primary_facility = $user->getPrimaryFacilityId(); 

        $d = Device::whereRaw('status = ? or id=?',array('unallocated',$user->device_id))->get();
        $devices = array('0'=>'Unknown'); 
        foreach($d as $k => $v) { $devices[$v->id] = $v->type.' - '.$v->tag; } 

	   return View::make('users.edit',array('user'=> $user, 
						'groups'=>$this->groups,
						'roles'=>$this->roles,
 						'devices' => $devices,
 						'pfacilities' => $this->pfacilities,
						'facilities'=>$this->facilities));
    }

	public function store()
	{
//            $checkloc = (Input::get('group')=='CCH' && preg_match('/.*?supervisor.*?/',strtolower(Input::get('role'))))

            $checkloc = (preg_match('/.*?supervisor.*?/',strtolower(Input::get('role'))))
                      ? true : false;

            if ($checkloc) { $this->rules['locations'] = 'required'; }

            $validator = Validator::make(Input::all(), $this->rules);

            $validator->sometimes('title', 'min:3', function($input) {
                return $input->title <> '';
            });


            if ($validator->fails()) {
		        //dd($validator->messages()->toJson());
                return Redirect::to('/users/create')
                        ->with('flash_error','true')
                        ->withInput()
                        ->withErrors($validator);
            } else {
                $user = new User;
                $user->username = Input::get('username');
                $user->password = Hash::make(Input::get('password'));
                $user->first_name = Input::get('first_name');
                $user->last_name = Input::get('last_name');
                $user->gender = Input::get('gender');
                $user->phone_number = Input::get('phone_number');
                $user->group = Input::get('group'); 
                $user->role = Input::get('role'); 
                $user->title = Input::get('title'); 
                $user->ischn = Input::get('ischn');
                $user->device_id = Input::get('device_id');
                $user->created_at = date('Y-m-d h:m:s');
                $user->modified_by = Auth::user()->id;
                $user->save();
	
		        // Add associate user with facility
                if ($checkloc) { $user->facilities()->sync(Input::get('locations')); }
                DB::update('UPDATE cch.cch_facility_user SET `primary`=1 WHERE user_id = ? and facility_id=?', array($user->id, Input::get('primary_facility')));

                // Update device status.
                DB::update('UPDATE cch.cch_devices SET status="unallocated", user_id=0 WHERE user_id = ?',array($user->id));
                DB::update('UPDATE cch.cch_devices SET status="active", user_id=? WHERE id = ?',array($user->id,$user->device_id));

		        // Add user to Oppia user's list
		        $postdata = array('username' => $user->username, 
				  'password' => Input::get('password'),
				  'passwordagain' => Input::get('password'),
				  'email' => $user->username.'@cch.gh.com',
				  'firstname' => $user->first_name,
				  'lastname'  => $user->last_name) ;

		        $url = 'http://localhost/cch/oppia/api/v1/register/';
		        $response = $this->curl_json_post($url, $postdata);

                Session::flash('message',"{$user->getName()} created successfully");
                return Redirect::to('/users');
            }
	}

	public function update($id)
	{
           $this->rules = array('username' => 'required|min:3|unique:cch_users,username,'.$id, 
			        'password' => 'required|min:6',
			        'confirmpassword' => 'required|same:password',
			        'first_name' => 'required|min:2',
			        'last_name' => 'required|min:2',
			        'group' => 'required|min:2',
			        'role' => 'required|min:2'
			       );

		//Added to lower case for  comparism
            $checkloc = (preg_match('/.*?supervisor.*?/',strtolower(Input::get('role'))))
                      ? true : false;
            if($checkloc) { $this->rules['locations'] = 'required'; }

            $validator = Validator::make(Input::all(), $this->rules);

            $validator->sometimes('title', 'min:3', function($input) {
                return $input->title <> '';
            });


            if ($validator->fails()) {
		        return Redirect::to('users/'.$id.'/edit')
                        ->with('flash_error','true')
                        ->withInput()
                        ->withErrors($validator);
            } else {
                $user = User::find($id);
                $oldu = $user->username;
                $olddevice = $user->device_id;

                $user->username = Input::get('username');
                $user->password = Hash::make(Input::get('password'));
                $user->first_name = Input::get('first_name');
                $user->last_name = Input::get('last_name');
                $user->gender = Input::get('gender');
                $user->phone_number = Input::get('phone_number');
                $user->group = Input::get('group'); 
                $user->role = Input::get('role'); 
                $user->title = Input::get('title'); 
                $user->ischn = Input::get('ischn');
                $user->device_id = Input::get('device_id');
                $user->modified_by = Auth::user()->id;
                $user->save();
	
                // Update device status.
                if ($olddevice != $user->device_id) {
                    DB::update('UPDATE cch.cch_devices SET status="unallocated", user_id=0 WHERE (user_id = ? OR id= ?)',array($user->id,$olddevice));
                    DB::update('UPDATE cch.cch_devices SET status="active", user_id=? WHERE id = ?',array($user->id,$user->device_id));
                }

		        // Add associate user with facility
                if ($checkloc) { $user->facilities()->sync(Input::get('locations')); }
                DB::update('UPDATE cch.cch_facility_user SET `primary`=1 WHERE user_id = ? and facility_id=?', array($user->id, Input::get('primary_facility')));

                // Update in tracker table
                Tracker::where('username', '=', $oldu)->update(array('username' => $user->username));

                // Update username in oppia auth table
                DB::update('UPDATE cch.auth_user SET username="'.$user->username.'" WHERE username = ?', array($oldu));

                Session::flash('message',"{$user->getName()} updated successfully");
                return Redirect::to('/users');
            }
	}
}
