@include('widgets.summary')                  

<div class="row">
    <div class="col-lg-12 col-xs-12">
        <hr/>
    </div>
</div>
    
<br/><br/>

@include('widgets.cch-moduleusage',array('dashboard'=>$dashboard))                  
